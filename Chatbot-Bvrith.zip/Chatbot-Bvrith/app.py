"""
app.py  —  BVRIT HYDERABAD FAQ Chatbot
Stack: Groq LLM · MiniLM embeddings (local) · ChromaDB · Streamlit
"""
import os, json, re, time
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

import streamlit as st

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="BVRIT Assistant",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* ── Base ── */
html, body, [class*="css"] { font-family: 'Segoe UI', sans-serif; }
.block-container { padding: 1.5rem 2rem 2rem 2rem !important; max-width: 100% !important; }

/* ── Sidebar background ── */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1b4b 0%, #1a2d6b 100%) !important;
}

/* ── Sidebar text colours ── */
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color: #dde5f7; }
[data-testid="stSidebar"] hr { border-color: rgba(255,255,255,0.15) !important; margin: 10px 0; }

/* ── Sidebar buttons ── */
[data-testid="stSidebar"] .stButton > button {
    background: rgba(255,255,255,0.08) !important;
    border: 1px solid rgba(255,255,255,0.18) !important;
    color: #e8edf8 !important;
    border-radius: 10px !important;
    font-size: 0.81rem !important;
    width: 100%;
    text-align: left !important;
    transition: background 0.15s;
}
[data-testid="stSidebar"] .stButton > button:hover {
    background: rgba(255,255,255,0.18) !important;
}

/* ── Sidebar selectbox & slider ── */
[data-testid="stSidebar"] .stSelectbox > div { color: #dde5f7 !important; }
[data-testid="stSidebar"] .stSlider { color: #dde5f7 !important; }

/* ── Branding block ── */
.sidebar-brand {
    background: linear-gradient(135deg, #2952cc 0%, #1a3a8f 100%);
    border-radius: 12px; padding: 18px 14px 14px;
    text-align: center; margin-bottom: 12px;
}
.sidebar-logo  { font-size: 2.5rem; }
.sidebar-title { font-size: 1rem; font-weight: 700; color: #fff; margin-top: 4px; }
.sidebar-sub   { font-size: 0.7rem; color: rgba(255,255,255,0.6); margin-top: 2px; }
.sidebar-section-label {
    font-size: 0.67rem; font-weight: 700; letter-spacing: 0.07em;
    color: rgba(255,255,255,0.4);
    text-transform: uppercase; padding: 10px 2px 4px; display: block;
}
.api-badge-ok {
    background: rgba(34,197,94,0.18); border: 1px solid rgba(34,197,94,0.35);
    color: #86efac; border-radius: 8px; padding: 7px 10px;
    font-size: 0.76rem; font-weight: 600; text-align: center;
}
.api-badge-err {
    background: rgba(239,68,68,0.18); border: 1px solid rgba(239,68,68,0.35);
    color: #fca5a5; border-radius: 8px; padding: 7px 10px;
    font-size: 0.76rem; font-weight: 600; text-align: center;
}
.metric-card {
    background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.12);
    border-radius: 8px; padding: 8px 10px; text-align: center; margin-bottom: 4px;
}
.metric-card .val { font-size: 1.1rem; font-weight: 700; color: #93c5fd; display: block; }
.metric-card .lbl { font-size: 0.68rem; color: rgba(255,255,255,0.45); display: block; }

/* ── Chat header bar ── */
.chat-topbar {
    background: linear-gradient(135deg, #0d1b4b 0%, #1a3a8f 55%, #2952cc 100%);
    padding: 14px 20px; border-radius: 14px; margin-bottom: 18px;
    display: flex; align-items: center; justify-content: space-between;
    box-shadow: 0 4px 18px rgba(13,27,75,0.25);
}
.topbar-left  { display: flex; align-items: center; gap: 12px; }
.topbar-icon  { font-size: 1.9rem; }
.topbar-title { color: #fff; font-size: 1.25rem; font-weight: 700; margin: 0; line-height: 1.2; }
.topbar-sub   { color: rgba(255,255,255,0.7); font-size: 0.76rem; margin-top: 2px; }
.topbar-greeting {
    background: rgba(255,255,255,0.14); border: 1px solid rgba(255,255,255,0.22);
    border-radius: 20px; padding: 5px 13px; color: #fff;
    font-size: 0.8rem; font-weight: 500; white-space: nowrap;
}

/* ── Chat bubbles ── */
.bubble-wrap { display: flex; margin: 6px 0; align-items: flex-end; gap: 8px; }
.bubble-wrap.user { justify-content: flex-end; }
.bubble-wrap.bot  { justify-content: flex-start; }
.avatar {
    width: 30px; height: 30px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 0.95rem; flex-shrink: 0;
}
.avatar.bot-av  { background: linear-gradient(135deg, #1a3a8f, #2952cc); }
.avatar.user-av { background: linear-gradient(135deg, #7c3aed, #a855f7); }
.bubble {
    max-width: 74%; padding: 11px 15px; border-radius: 18px;
    font-size: 0.89rem; line-height: 1.6; word-wrap: break-word;
    box-shadow: 0 2px 6px rgba(0,0,0,0.07);
}
.bubble.user {
    background: linear-gradient(135deg, #2952cc, #1a3a8f);
    color: #fff; border-bottom-right-radius: 4px;
}
.bubble.bot {
    background: #fff; color: #1a1a2e;
    border: 1px solid #e4eaf7; border-bottom-left-radius: 4px;
}
.bubble.thinking { color: #94a3b8; font-style: italic; }
.msg-meta { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 5px; align-items: center; }
.src-tag {
    background: #eef2ff; color: #3730a3; border: 1px solid #c7d2fe;
    border-radius: 20px; padding: 2px 8px; font-size: 0.67rem; font-weight: 600;
}
.refused-tag {
    background: #fff1f2; color: #be123c; border: 1px solid #fecdd3;
    border-radius: 20px; padding: 2px 8px; font-size: 0.67rem; font-weight: 600;
}
.time-tag { color: #94a3b8; font-size: 0.65rem; margin-left: 4px; }

/* ── Welcome card ── */
.welcome-card {
    background: linear-gradient(135deg, #eef2ff, #f0fdf4);
    border: 1px solid #c7d2fe; border-radius: 14px;
    padding: 20px 22px; margin-bottom: 18px;
    display: flex; gap: 14px; align-items: flex-start;
}
.welcome-icon  { font-size: 2.2rem; flex-shrink: 0; }
.welcome-title { font-size: 1rem; font-weight: 700; color: #1e3a8a; margin-bottom: 4px; }
.welcome-body  { font-size: 0.83rem; color: #475569; line-height: 1.55; }

/* ── Chat input ── */
.stChatInput > div {
    border-radius: 14px !important;
    border: 2px solid #c7d2fe !important;
    background: #fff !important;
}
.stChatInput > div:focus-within {
    border-color: #2952cc !important;
    box-shadow: 0 0 0 3px rgba(41,82,204,0.12) !important;
}

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-thumb { background: #c7d2fe; border-radius: 10px; }
</style>
""", unsafe_allow_html=True)


# ── Persistence paths ─────────────────────────────────────────────────────────
HISTORY_FILE    = Path(__file__).parent / "chat_history.json"
USER_PREFS_FILE = Path(__file__).parent / "user_prefs.json"

# ── Disk helpers ──────────────────────────────────────────────────────────────
def load_user_prefs() -> dict:
    if USER_PREFS_FILE.exists():
        try:
            return json.loads(USER_PREFS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}

def save_user_prefs(prefs: dict):
    try:
        USER_PREFS_FILE.write_text(json.dumps(prefs, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

def load_all_sessions() -> dict:
    if HISTORY_FILE.exists():
        try:
            return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}

def save_all_sessions(sessions: dict):
    try:
        HISTORY_FILE.write_text(json.dumps(sessions, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

def new_session_id() -> str:
    return f"sess_{int(time.time())}"

def session_title(messages: list) -> str:
    for m in messages:
        if m["role"] == "user":
            t = m["content"][:45]
            return t + ("…" if len(m["content"]) > 45 else "")
    return "New chat"

# ── Name detection ────────────────────────────────────────────────────────────
_NAME_RE = [
    r"(?:my name is|i am|i'm|call me|this is)\s+([A-Za-z][a-z]+(?:\s+[A-Za-z][a-z]+)?)",
    r"^([A-Za-z][a-z]{2,})(?:\s+here)?[.!]?\s*$",
]
_SKIP_WORDS = {"hi","hello","hey","bvrit","sure","ok","okay","yes","no","thanks","thank",
               "please","what","who","how","when","where","tell","give","show"}

def extract_name(text: str) -> str | None:
    for pat in _NAME_RE:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            name = m.group(1).strip().title()
            if name.lower().split()[0] not in _SKIP_WORDS:
                return name
    return None

# ── Cached resources ──────────────────────────────────────────────────────────
@st.cache_resource(show_spinner="📚 Loading knowledge base…")
def load_index():
    from ingest_index import build_or_load_index
    return build_or_load_index(force_rebuild=False)

@st.cache_resource(show_spinner=False)
def get_chain_cached(section_filter: str, top_k: int):
    from rag_chain import get_rag_chain
    return get_rag_chain(section_filter=section_filter, top_k=top_k)

@st.cache_resource(show_spinner="⚡ Warming up AI…")
def warm_embeddings():
    from rag_chain import get_embeddings
    emb = get_embeddings()
    emb.embed_query("warm up")
    return True

# ── Session helpers ───────────────────────────────────────────────────────────
def _persist_current():
    sid  = st.session_state.get("current_sid")
    msgs = st.session_state.get("messages", [])
    if not sid or not msgs:
        return
    sessions = st.session_state.get("all_sessions", {})
    sessions[sid] = {
        "title":     session_title(msgs),
        "timestamp": time.strftime("%d %b %Y, %H:%M"),
        "messages":  msgs,
    }
    st.session_state.all_sessions = sessions
    save_all_sessions(sessions)

def _new_session():
    _persist_current()
    sid = new_session_id()
    st.session_state.current_sid = sid
    st.session_state.messages    = []

def _load_session(sid: str):
    _persist_current()
    sess = st.session_state.get("all_sessions", {}).get(sid, {})
    st.session_state.current_sid = sid
    st.session_state.messages    = sess.get("messages", [])

def _init_state():
    if "sessions_loaded" not in st.session_state:
        st.session_state.sessions_loaded = True
        st.session_state.all_sessions    = load_all_sessions()
        prefs = load_user_prefs()
        st.session_state.user_name   = prefs.get("user_name", "")
        st.session_state.current_sid = new_session_id()
        st.session_state.messages    = []
        st.session_state.active_tab  = "chat"   # "chat" | "eval"

# ── Misc ──────────────────────────────────────────────────────────────────────
def is_refusal(text: str) -> bool:
    markers = ["i don't have that information", "not in my knowledge base",
               "please contact bvrit", "i can only answer", "cannot guarantee",
               "i'm not sure what you're asking"]
    return any(m in text.lower() for m in markers)


# ── Render one message ────────────────────────────────────────────────────────
def render_message(msg: dict):
    role    = msg["role"]
    content = msg["content"]
    ts      = msg.get("ts", "")
    if role == "user":
        st.markdown(
            f'<div class="bubble-wrap user">'
            f'<div class="bubble user">{content}</div>'
            f'<div class="avatar user-av">👩‍🎓</div>'
            f'</div>', unsafe_allow_html=True)
    else:
        src_html = ""
        if msg.get("sources"):
            tags = "".join(f'<span class="src-tag">📌 {s}</span>' for s in msg["sources"])
            src_html = f'<div class="msg-meta">{tags}'
        else:
            src_html = '<div class="msg-meta">'
        if msg.get("refused"):
            src_html += '<span class="refused-tag">🚫 Out of scope</span>'
        if ts:
            src_html += f'<span class="time-tag">{ts}</span>'
        src_html += '</div>'
        st.markdown(
            f'<div class="bubble-wrap bot">'
            f'<div class="avatar bot-av">🎓</div>'
            f'<div><div class="bubble bot">{content}</div>{src_html}</div>'
            f'</div>', unsafe_allow_html=True)

# ── Sections ──────────────────────────────────────────────────────────────────
SECTIONS = [
    "All Sections",
    "Section 1: About BVRIT HYDERABAD",
    "Section 2: Departments & Programmes",
    "Section 3: Fee Structure",
    "Section 4: Scholarships & Fee Concessions",
    "Section 5: Admissions",
    "Section 6: Placements",
    "Section 7: Campus & Facilities",
    "Section 8: Key Faculty & Leadership",
    "Section 9: Research & Innovation",
    "Section 10: Student Support Services",
    "Section 11: Contact Information",
]

# ── Sidebar ───────────────────────────────────────────────────────────────────
def render_sidebar(chunk_count: int):
    with st.sidebar:
        # Brand block
        user_name = st.session_state.get("user_name", "")
        st.markdown(f"""
        <div class="sidebar-brand">
            <div class="sidebar-logo">🎓</div>
            <div class="sidebar-title">BVRIT Assistant</div>
            <div class="sidebar-sub">Hyderabad · Women's College</div>
            {"<div style='margin-top:8px;font-size:0.8rem;color:rgba(255,255,255,0.8)'>👋 Hi, <b>" + user_name + "</b>!</div>" if user_name else ""}
        </div>""", unsafe_allow_html=True)

        # API status
        groq_key = os.getenv("GROQ_API_KEY", "").strip()
        if groq_key:
            display = groq_key[:5] + "…" + groq_key[-3:]
            st.markdown(f'<div class="api-badge-ok">✅ Groq API connected ({display})</div>',
                        unsafe_allow_html=True)
        else:
            st.markdown('<div class="api-badge-err">❌ GROQ_API_KEY missing in .env</div>',
                        unsafe_allow_html=True)
        st.markdown("<br>", unsafe_allow_html=True)

        # ── Eval dashboard button ─────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-label">📊 Evaluation</div>', unsafe_allow_html=True)
        if st.button("📊 Open Evaluation Dashboard", use_container_width=True, key="sidebar_eval_btn"):
            st.session_state.active_tab = "eval"
            st.rerun()
        # ── Governance dashboard button (Day 5 Session 4) ────────────────────
        if st.button("🛡️ Governance Dashboard", use_container_width=True, key="sidebar_gov_btn"):
            st.session_state.active_tab = "governance"
            st.rerun()
        if st.button("💬 Back to Chat", use_container_width=True, key="sidebar_chat_btn"):
            st.session_state.active_tab = "chat"
            st.rerun()

        st.markdown("---")

        # ── Chat history ──────────────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-label">💬 Conversations</div>',
                    unsafe_allow_html=True)

        if st.button("➕  New Chat", use_container_width=True, key="new_chat", type="primary"):
            _new_session()
            st.session_state.active_tab = "chat"
            st.rerun()

        sessions    = st.session_state.get("all_sessions", {})
        current_sid = st.session_state.get("current_sid", "")
        sorted_sids = sorted(sessions.keys(), reverse=True)[:15]

        for sid in sorted_sids:
            sess      = sessions[sid]
            title     = sess.get("title", "Chat")
            ts        = sess.get("timestamp", "")
            is_active = (sid == current_sid)
            label     = f"{'▶  ' if is_active else ''}{title[:30]}"
            if st.button(label, key=f"h_{sid}", use_container_width=True, help=ts):
                _load_session(sid)
                st.session_state.active_tab = "chat"
                st.rerun()

        if not sorted_sids:
            st.markdown('<p style="font-size:0.78rem;color:rgba(255,255,255,0.4);padding:6px 4px">No saved chats yet.</p>',
                        unsafe_allow_html=True)

        st.markdown("---")

        # ── KB status ─────────────────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-label">📚 Knowledge Base</div>',
                    unsafe_allow_html=True)
        ok_col = "#86efac" if chunk_count > 0 else "#fca5a5"
        ok_lbl = "READY" if chunk_count > 0 else "NOT BUILT"
        st.markdown(
            f'<div class="metric-card">'
            f'<div class="val" style="color:{ok_col} !important">{ok_lbl}</div>'
            f'<div class="lbl">{chunk_count} chunks · MiniLM-L6</div></div>',
            unsafe_allow_html=True)

        # ── Retrieval settings ────────────────────────────────────────────────
        st.markdown('<div class="sidebar-section-label">⚙️ Retrieval</div>',
                    unsafe_allow_html=True)
        top_k          = st.slider("TOP_K chunks", 1, 8, 4, 1)
        section_filter = st.selectbox("Section filter", SECTIONS, label_visibility="collapsed")

        # ── Last query metrics ────────────────────────────────────────────────
        if "last_latency" in st.session_state:
            st.markdown('<div class="sidebar-section-label">⚡ Last Query</div>',
                        unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            c1.markdown(
                f'<div class="metric-card"><div class="val">{st.session_state.last_latency}s</div>'
                f'<div class="lbl">Latency</div></div>', unsafe_allow_html=True)
            c2.markdown(
                f'<div class="metric-card"><div class="val">{st.session_state.get("last_chunks",0)}</div>'
                f'<div class="lbl">Chunks</div></div>', unsafe_allow_html=True)

        # ── RAGAS scores ──────────────────────────────────────────────────────
        results_file = Path("eval_results.json")
        if results_file.exists():
            try:
                rpt = json.loads(results_file.read_text(encoding="utf-8"))
                rs  = rpt.get("ragas_scores", {})
                if rs and not (rs.get("error") and "proxy" not in str(rs.get("error","")).lower()):
                    st.markdown('<div class="sidebar-section-label">📊 RAGAS</div>',
                                unsafe_allow_html=True)
                    for key, lbl in [("faithfulness","Faithful"),("answer_relevancy","Relevant"),
                                     ("context_precision","Precision"),("context_recall","Recall")]:
                        val = float(rs.get(key, 0.0))
                        col = "#86efac" if val >= 0.8 else "#fde68a" if val >= 0.6 else "#fca5a5"
                        st.markdown(
                            f'<div style="display:flex;justify-content:space-between;'
                            f'align-items:center;padding:3px 4px">'
                            f'<span style="font-size:0.74rem;color:rgba(255,255,255,0.65)">{lbl}</span>'
                            f'<span style="font-size:0.74rem;font-weight:700;color:{col}">{val:.2f}</span>'
                            f'</div>', unsafe_allow_html=True)
                        st.progress(val)
            except Exception:
                pass

        st.markdown("---")
        st.markdown('<p style="font-size:0.7rem;color:rgba(255,255,255,0.3);text-align:center;padding:4px">100% Free · No paid API</p>',
                    unsafe_allow_html=True)

    return top_k, section_filter


# ── Chat Tab ──────────────────────────────────────────────────────────────────
SUGGESTIONS = [
    ("📋", "List all B.Tech programmes"),
    ("💰", "CSE tuition fees per year"),
    ("🏆", "Placement stats 2024-25"),
    ("🎓", "Scholarships available"),
    ("🏠", "Hostel fee and facilities"),
    ("👩‍💼", "Who is the principal?"),
    ("📍", "College address"),
    ("📞", "Contact information"),
]

def render_chat_tab(top_k: int, section_filter: str):
    groq_key  = os.getenv("GROQ_API_KEY", "").strip()
    user_name = st.session_state.get("user_name", "")
    name_part = f", {user_name}" if user_name else ""

    # Top bar
    st.markdown(f"""
    <div class="chat-topbar">
        <div class="topbar-left">
            <div class="topbar-icon">🎓</div>
            <div>
                <div class="topbar-title">BVRIT HYDERABAD FAQ Chatbot</div>
                <div class="topbar-sub">College of Engineering for Women · Bachupally, Hyderabad</div>
            </div>
        </div>
        {"<div class='topbar-greeting'>👋 Hi, <b>" + user_name + "</b>!</div>" if user_name else ""}
    </div>""", unsafe_allow_html=True)

    if not groq_key:
        st.error("**GROQ_API_KEY not found.** Add it to `.env` and restart.")
        return

    messages = st.session_state.get("messages", [])

    # Welcome card + suggestions when empty
    if not messages:
        greeting = f"Hello{name_part}! 👋 I'm your BVRIT HYDERABAD assistant." if user_name \
                   else "Welcome! 👋 I'm your BVRIT HYDERABAD assistant."
        st.markdown(f"""
        <div class="welcome-card">
            <div class="welcome-icon">🎓</div>
            <div>
                <div class="welcome-title">{greeting}</div>
                <div class="welcome-body">
                    Ask me anything about <b>admissions, fees, placements, scholarships,
                    hostel, faculty,</b> and more. I answer only from the official
                    BVRIT HYDERABAD knowledge base — no guessing.
                </div>
            </div>
        </div>""", unsafe_allow_html=True)

        st.markdown('<div class="suggestions-wrap"><p>💡 Quick questions — click to ask:</p>'
                    '<div class="suggestion-chips">', unsafe_allow_html=True)
        # render suggestion chips as Streamlit buttons
        cols = st.columns(4)
        for i, (icon, text) in enumerate(SUGGESTIONS):
            with cols[i % 4]:
                if st.button(f"{icon} {text}", key=f"sug_{i}", use_container_width=True):
                    st.session_state.messages.append({"role": "user", "content": text,
                                                       "ts": time.strftime("%H:%M")})
                    st.rerun()
        st.markdown('</div></div>', unsafe_allow_html=True)
        st.markdown("---")

    # Render chat history
    st.markdown('<div class="chat-area">', unsafe_allow_html=True)
    for msg in messages:
        render_message(msg)
    st.markdown('</div>', unsafe_allow_html=True)

    # Thinking placeholder + input
    typing_ph  = st.empty()
    user_input = st.chat_input(f"Ask anything about BVRIT HYDERABAD{name_part}…")

    if user_input:
        # Detect name
        detected = extract_name(user_input)
        if detected:
            st.session_state.user_name = detected
            prefs = load_user_prefs()
            prefs["user_name"] = detected
            save_user_prefs(prefs)

        ts = time.strftime("%H:%M")
        st.session_state.messages.append({"role": "user", "content": user_input, "ts": ts})
        render_message({"role": "user", "content": user_input, "ts": ts})

        typing_ph.markdown(
            '<div class="bubble-wrap bot">'
            '<div class="avatar bot-av">🎓</div>'
            '<div class="bubble bot thinking">Thinking…</div>'
            '</div>', unsafe_allow_html=True)

        try:
            chain   = get_chain_cached(section_filter, top_k)
            history = [{"role": m["role"], "content": m["content"]}
                       for m in st.session_state.messages[:-1]]
            current_name = st.session_state.get("user_name", "")
            if current_name:
                history = [{"role": "system",
                            "content": f"The user's name is {current_name}."}] + history

            # Auto-retry up to 4 times on rate-limit (429) with backoff
            result = None
            last_err = None
            for _attempt in range(4):
                try:
                    result = chain.answer(user_input, history=history)
                    break
                except Exception as _e:
                    last_err = _e
                    _es = str(_e)
                    if "429" in _es or "rate_limit" in _es.lower() or "rate limit" in _es.lower():
                        wait = 15 * (2 ** _attempt)   # 15 → 30 → 60 → 120 s
                        typing_ph.markdown(
                            f'<div class="bubble-wrap bot">'
                            f'<div class="avatar bot-av">🎓</div>'
                            f'<div class="bubble bot thinking">⏳ Rate limit — retrying in {wait}s… (attempt {_attempt+1}/4)</div>'
                            f'</div>', unsafe_allow_html=True)
                        time.sleep(wait)
                    else:
                        raise  # non-429 → surface immediately

            if result is None:
                raise last_err

            typing_ph.empty()
            answer     = result["answer"]
            sources    = result["sources"]
            latency    = result["latency"]
            num_chunks = result["num_chunks"]
            refused    = is_refusal(answer)

        except Exception as e:
            typing_ph.empty()
            err = str(e)
            if "401" in err or "api_key" in err.lower() or "authentication" in err.lower():
                answer = "❌ Invalid Groq API key. Check `.env` — key must start with `gsk_`."
            elif "429" in err or "rate" in err.lower():
                answer = ("⏳ Groq rate limit reached. Your free tier allows 6,000 tokens/min "
                          "and 100,000 tokens/day. Please wait a few minutes and try again, "
                          "or get a new key at https://console.groq.com")
            else:
                answer = f"❌ Error: {err[:200]}"
            sources, latency, num_chunks, refused = [], 0.0, 0, False

        reply = {
            "role": "assistant", "content": answer, "sources": sources,
            "latency": latency, "num_chunks": num_chunks, "refused": refused,
            "ts": time.strftime("%H:%M"),
        }
        st.session_state.messages.append(reply)
        render_message(reply)
        _persist_current()

        st.session_state.last_latency = latency
        st.session_state.last_chunks  = num_chunks
        st.session_state.last_sources = sources
        st.rerun()

    # Clear button
    if messages:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🗑️ Clear this chat", type="secondary"):
            st.session_state.messages = []
            _persist_current()
            for k in ("last_latency", "last_chunks", "last_sources"):
                st.session_state.pop(k, None)
            st.rerun()

# ── Evaluation Tab ────────────────────────────────────────────────────────────
DIM_LABELS = {
    "01_Functional":"⚙️ Functional","02_Quality":"🎯 Quality",
    "03_Safety":"🛡️ Safety",        "04_Security":"🔒 Security",
    "05_Robustness":"💪 Robustness","06_Performance":"⚡ Performance",
    "07_Context":"💬 Context",       "08_RAGAS":"📊 RAGAS",
}

def render_eval_tab():
    st.markdown("## 📊 Evaluation Dashboard — 8 Dimensions")
    st.caption("Automated test suite: 20 cases · Functional · Quality · Safety · Security · Robustness · Performance · Context · RAGAS")

    if not os.getenv("GROQ_API_KEY", "").strip():
        st.warning("GROQ_API_KEY missing in `.env`.")
        return

    results_file = Path("eval_results.json")
    col_run, col_fresh, col_back = st.columns([2, 2, 2])
    with col_run:
        run_btn = st.button("▶️ Run Evaluation", type="primary", use_container_width=True)
    with col_fresh:
        fresh_btn = st.button("🔄 Re-run Fresh", type="secondary", use_container_width=True)
    with col_back:
        if st.button("💬 Back to Chat", use_container_width=True):
            st.session_state.active_tab = "chat"
            st.rerun()

    if run_btn or fresh_btn:
        if fresh_btn and results_file.exists():
            results_file.unlink()
        prog = st.progress(0, text="Starting…")
        status = st.empty()
        try:
            status.info("1/4 – Loading test cases…"); prog.progress(10)
            from test_generator import load_or_generate
            cases = load_or_generate()

            status.info(f"2/4 – Running {len(cases)} test cases…"); prog.progress(30)
            from rag_chain import RAGChain
            from evaluator import run_test_suite, judge_all, run_ragas, compile_report
            chain = RAGChain()
            raw   = run_test_suite(cases, chain); prog.progress(56)

            status.info("3/4 – Judging with Groq LLM-as-judge…")
            judged = judge_all(raw); prog.progress(76)

            status.info("4/4 – Computing RAGAS scores…")
            ragas_scores = run_ragas([r for r in judged if r["dimension"] == "08_RAGAS"])
            prog.progress(92)

            report = compile_report(judged, ragas_scores)
            results_file.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
            prog.progress(100); status.success("Evaluation complete!")
            time.sleep(0.5); status.empty(); prog.empty()
            st.rerun()
        except Exception as e:
            status.error(f"Evaluation failed: {e}"); prog.empty()
        return

    if not results_file.exists():
        st.info("Click **▶️ Run Evaluation** to generate the report.")
        return

    report = json.loads(results_file.read_text(encoding="utf-8"))
    s      = report["summary"]
    rs     = report.get("ragas_scores", {})
    by_dim = report.get("by_dimension", {})

    # Summary
    st.markdown("### 📋 Summary")
    m1,m2,m3,m4,m5 = st.columns(5)
    m1.metric("Total",     s["total"])
    m2.metric("Passed ✅", s["passed"])
    m3.metric("Failed ❌", s["failed"])
    m4.metric("Warned ⚠️", s["warned"])
    pr   = s["pass_rate"]
    icon = "🟢" if pr >= 75 else "🟡" if pr >= 50 else "🔴"
    m5.metric("Pass Rate", f"{icon} {pr}%")
    weakest = s.get("weakest_dimension")
    if weakest and by_dim.get(weakest):
        wd = by_dim[weakest]
        st.warning(f"Weakest: **{DIM_LABELS.get(weakest,weakest)}** — {wd['passed']}/{wd['total']} passed")
    st.markdown("---")

    # RAGAS
    st.markdown("### 📊 RAGAS Metrics")
    if rs.get("error") and "proxy" not in str(rs.get("error","")).lower():
        st.info(f"ℹ️ {rs['error']}")
    else:
        if rs.get("error"):
            st.caption(f"Note: {rs['error']}")
        rc1,rc2,rc3,rc4 = st.columns(4)
        for col,(key,lbl) in zip([rc1,rc2,rc3,rc4],[
            ("faithfulness","Faithfulness"),("answer_relevancy","Answer Relevancy"),
            ("context_precision","Context Precision"),("context_recall","Context Recall")
        ]):
            val = float(rs.get(key,0.0))
            col.metric(lbl, f"{val:.2f}"); col.progress(val)
    st.markdown("---")

    # Per-dimension
    st.markdown("### 🗂️ Dimension Results")
    col_a, col_b = st.columns(2)
    for i, dim in enumerate(sorted(by_dim.keys())):
        stats = by_dim[dim]
        p,f,t = stats["passed"],stats["failed"],stats["total"]
        rate  = round(p/t*100) if t else 0
        label = DIM_LABELS.get(dim, dim)
        with (col_a if i%2==0 else col_b):
            with st.expander(f"{label} — {p}/{t} passed ({rate}%)", expanded=(f>0)):
                st.progress(rate/100)
                for case in stats["cases"]:
                    v     = case.get("verdict","WARN")
                    emoji = {"PASS":"✅","FAIL":"❌","WARN":"⚠️"}[v]
                    color = {"PASS":"#22c55e","FAIL":"#ef4444","WARN":"#f59e0b"}[v]
                    st.markdown(
                        f'**{emoji} {case["test_id"]}** — '
                        f'<span style="color:{color};font-weight:700">{v}</span>',
                        unsafe_allow_html=True)
                    st.caption(f"Q: {case['question'][:110]}")
                    if case.get("judge_reason"):
                        st.caption(f"Judge: {case['judge_reason']}")
                    if v in ("FAIL","WARN") and case.get("fix_suggestion"):
                        st.error(f"Fix: {case['fix_suggestion']}")
                    if v == "FAIL":
                        with st.expander("View detail", expanded=False):
                            st.markdown("**Expected:**"); st.info(case.get("expected_answer",""))
                            st.markdown("**Actual:**");   st.warning(case.get("actual_answer","")[:400])
                    st.markdown("---")

    # Recommendations
    st.markdown("### 🔧 Recommendations")
    fails = [r for d in by_dim.values() for r in d["cases"]
             if r.get("verdict")=="FAIL" and r.get("fix_suggestion")]
    if fails:
        for r in fails:
            st.markdown(f"- **{DIM_LABELS.get(r['dimension'],r['dimension'])}** `{r['test_id']}`: {r['fix_suggestion']}")
    else:
        st.success("🎉 All test cases passed!")

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    _init_state()
    warm_embeddings()

    try:
        vs, chunk_count = load_index()
    except Exception as e:
        st.error(f"Failed to load knowledge base: {e}")
        chunk_count = 0

    top_k, section_filter = render_sidebar(chunk_count)

    active = st.session_state.get("active_tab", "chat")

    if active == "eval":
        render_eval_tab()
    elif active == "governance":
        # Governance Dashboard — Day 5 Session 4
        from governance.governance_dashboard import render_governance_dashboard
        render_governance_dashboard()
    else:
        render_chat_tab(top_k, section_filter)

if __name__ == "__main__":
    main()
