"""
ingest_index.py
Loads bvrit_info.txt, splits into chunks, embeds with FREE local model
(sentence-transformers all-MiniLM-L6-v2), and stores in ChromaDB.
Zero API cost for indexing.
"""
import os
import re
import hashlib
import shutil
from pathlib import Path
from dotenv import load_dotenv
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

load_dotenv()

# ── Config from .env ─────────────────────────────────────────────────────────
KNOWLEDGE_FILE  = Path(os.getenv("KNOWLEDGE_FILE", "./bvrit_info.txt"))
CHROMA_DIR      = Path(os.getenv("CHROMA_DIR", "./chroma_db"))
CHUNK_SIZE      = int(os.getenv("CHUNK_SIZE", "600"))
CHUNK_OVERLAP   = int(os.getenv("CHUNK_OVERLAP", "100"))
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "bvrit_knowledge")

# Free local embedding model — no API key needed, runs on CPU
EMBED_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

def get_embeddings() -> HuggingFaceEmbeddings:
    return HuggingFaceEmbeddings(
        model_name=EMBED_MODEL_NAME,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )

# ── Section detection ─────────────────────────────────────────────────────────
_SECTION_PATTERNS = [
    (r"SECTION\s+1[:\s].*ABOUT",      "Section 1: About BVRIT HYDERABAD"),
    (r"SECTION\s+2[:\s].*DEPARTMENT", "Section 2: Departments & Programmes"),
    (r"SECTION\s+3[:\s].*FEE",        "Section 3: Fee Structure"),
    (r"SECTION\s+4[:\s].*SCHOLAR",    "Section 4: Scholarships & Fee Concessions"),
    (r"SECTION\s+5[:\s].*ADMISS",     "Section 5: Admissions"),
    (r"SECTION\s+6[:\s].*PLACEMENT",  "Section 6: Placements"),
    (r"SECTION\s+7[:\s].*CAMPUS",     "Section 7: Campus & Facilities"),
    (r"SECTION\s+8[:\s].*FACULTY",    "Section 8: Key Faculty & Leadership"),
    (r"SECTION\s+9[:\s].*RESEARCH",   "Section 9: Research & Innovation"),
    (r"SECTION\s+10[:\s].*STUDENT",   "Section 10: Student Support Services"),
    (r"SECTION\s+11[:\s].*CONTACT",   "Section 11: Contact Information"),
    (r"SECTION\s+12[:\s].*FAQ",       "Section 12: FAQs"),
]

def _detect_section(text: str) -> str:
    upper = text.upper()
    for pattern, label in _SECTION_PATTERNS:
        if re.search(pattern, upper):
            return label
    return "General"

# ── Load and split ─────────────────────────────────────────────────────────────
def load_and_split() -> list:
    raw = KNOWLEDGE_FILE.read_text(encoding="utf-8")
    section_re = re.compile(r"(={60,}\s*\n(?:SECTION\s+\d+[:\s].+?)\n={60,})", re.DOTALL)
    parts = section_re.split(raw)

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    current_section = "General"
    documents = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        heading = _detect_section(part)
        if heading != "General":
            current_section = heading
        for chunk in splitter.split_text(part):
            chunk = chunk.strip()
            if len(chunk) < 30:
                continue
            documents.append({
                "text": chunk,
                "metadata": {
                    "source": "bvrit_info.txt",
                    "section": current_section,
                    "chunk_length": len(chunk),
                }
            })
    return documents

# ── Collection count ──────────────────────────────────────────────────────────
def _count(vs: Chroma) -> int:
    try:
        return vs._collection.count()
    except Exception:
        try:
            return vs._client.get_collection(COLLECTION_NAME).count()
        except Exception:
            return 0

# ── Build / load index ────────────────────────────────────────────────────────
def build_or_load_index(force_rebuild: bool = False):
    embeddings = get_embeddings()

    if CHROMA_DIR.exists() and not force_rebuild:
        vs = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=embeddings,
            persist_directory=str(CHROMA_DIR),
        )
        count = _count(vs)
        if count > 0:
            print(f"[ingest] Loaded existing index — {count} chunks.")
            return vs, count

    if CHROMA_DIR.exists() and force_rebuild:
        shutil.rmtree(str(CHROMA_DIR))

    print(f"[ingest] Building ChromaDB index from {KNOWLEDGE_FILE.name} …")
    print(f"[ingest] Using FREE local embeddings: {EMBED_MODEL_NAME}")
    documents = load_and_split()
    texts     = [d["text"]     for d in documents]
    metadatas = [d["metadata"] for d in documents]
    ids       = [hashlib.md5(t.encode()).hexdigest() for t in texts]

    vs = Chroma.from_texts(
        texts=texts,
        metadatas=metadatas,
        ids=ids,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=str(CHROMA_DIR),
    )
    print(f"[ingest] Indexed {len(texts)} chunks. Zero API cost.")
    return vs, len(texts)

def get_chunk_count() -> int:
    if not CHROMA_DIR.exists():
        return 0
    try:
        vs = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=get_embeddings(),
            persist_directory=str(CHROMA_DIR),
        )
        return _count(vs)
    except Exception:
        return 0

if __name__ == "__main__":
    vs, n = build_or_load_index(force_rebuild=True)
    print(f"\n✅  Index ready — {n} chunks in {CHROMA_DIR}")
    results = vs.similarity_search("What are the tuition fees for CSE?", k=3)
    print("\n--- Test retrieval ---")
    for i, r in enumerate(results):
        print(f"[{i+1}] [{r.metadata['section']}]  {r.page_content[:100]}…")
