# BVRIT HYDERABAD FAQ Chatbot 🎓

RAG-powered chatbot for BVRIT HYDERABAD College of Engineering for Women.
Built with LangChain · ChromaDB · OpenRouter · Streamlit · RAGAS.

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Set your API key
Edit `.env` and add your OpenRouter API key:
```
OPENROUTER_API_KEY=sk-or-xxxxxxxxxxxxxx
```
Get a key at https://openrouter.ai

### 3. Build the knowledge index (first time only)
```bash
python ingest_index.py
```

### 4. Run the app
```bash
streamlit run app.py
```

Open http://localhost:8501 in your browser.

---

## Project Structure

| File | Purpose |
|------|---------|
| `app.py` | Streamlit app — Chat tab + Evaluation Dashboard tab |
| `rag_chain.py` | RAG pipeline — retriever + grounding prompt + LLM |
| `ingest_index.py` | Document loader, chunker, ChromaDB indexer |
| `test_generator.py` | LLM-based test case generator (8 dimensions, 20 cases) |
| `evaluator.py` | Test runner, LLM-as-judge, RAGAS scoring, report compiler |
| `bvrit_info.txt` | College knowledge base document |
| `chroma_db/` | Persisted vector store (auto-created) |
| `test_cases.json` | Generated test cases (auto-created) |
| `eval_results.json` | Evaluation report (auto-created) |

## Features

- **RAG Pipeline**: Every answer is grounded in bvrit_info.txt — no hallucination
- **Citations**: Every response shows the source section
- **Refusal**: Gracefully refuses out-of-scope questions with contact info
- **Image Generation**: Toggle image mode to generate college-related images
- **Section Filter**: Sidebar dropdown to restrict retrieval to a specific section
- **Multi-turn Context**: Follow-up questions maintain conversation context
- **8-Dimension Evaluation**: Full automated test suite with LLM-as-judge
- **RAGAS Scoring**: Faithfulness, Answer Relevancy, Context Precision, Context Recall

## Evaluation Dimensions

| # | Dimension | Cases | Description |
|---|-----------|-------|-------------|
| 01 | Functional | 3 | Format compliance, citations, completeness |
| 02 | Quality | 3 | Factual accuracy, exact figures |
| 03 | Safety | 2 | No harmful guarantees, no bias |
| 04 | Security | 2 | Prompt injection resistance |
| 05 | Robustness | 3 | Edge cases, gibberish, mixed language |
| 06 | Performance | 2 | Response time within 15s SLA |
| 07 | Context | 2 | Multi-turn conversation handling |
| 08 | RAGAS | 3 | Automated RAG quality metrics |
