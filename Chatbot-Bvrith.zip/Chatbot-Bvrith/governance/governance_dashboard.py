"""
governance/governance_dashboard.py
====================================
Exercise 5 — Governance Streamlit Dashboard

Renders the full AI Governance tab inside the BVRIT Chatbot Streamlit app.

Public API
----------
    render_governance_dashboard()   — call from app.py inside a tab

Sections
--------
  1. Overall scores (7 KPI cards)
  2. Interactive charts (radar, bar, timeline)
  3. Latest scan findings table
  4. Download buttons for all reports
  5. Re-run buttons for each tool
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

BASE_DIR    = Path(__file__).resolve().parent.parent
REPORTS_DIR = BASE_DIR / "reports"

# ── Report file paths ─────────────────────────────────────────────────────────
_GISKARD_JSON   = REPORTS_DIR / "giskard_scan_results.json"
_PROMPTFOO_JSON = REPORTS_DIR / "promptfoo" / "promptfoo_results.json"
_DEEPEVAL_JSON  = REPORTS_DIR / "deepeval_metrics.json"
_FAIRNESS_JSON  = REPORTS_DIR / "fairness_results.json"
_GOV_REPORT_MD  = REPORTS_DIR / "governance_report.md"
_FAIRNESS_MD    = REPORTS_DIR / "fairness_report.md"
_GISKARD_MD     = REPORTS_DIR / "giskard_scan_report.md"
_DEEPEVAL_MD    = REPORTS_DIR / "deepeval_summary.md"
_PROMPTFOO_MD   = REPORTS_DIR / "promptfoo" / "promptfoo_report.md"


# ─────────────────────────────────────────────────────────────────────────────
# Data loaders
# ─────────────────────────────────────────────────────────────────────────────

def _load_json(path: Path) -> Any:
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None
    return None


def _compute_scores() -> dict:
    """
    Aggregate scores from all report JSONs.
    Returns a dict with all governance KPI scores (0-100).
    """
    scores = {
        "overall":           0.0,
        "security":          0.0,
        "fairness":          0.0,
        "hallucination":     0.0,
        "faithfulness":      0.0,
        "bias":              0.0,
        "toxicity":          0.0,
        "injection_resistance": 0.0,
        "relevancy":         0.0,
        "critical_issues":   0,
        "medium_issues":     0,
        "low_issues":        0,
        "last_scan":         "Never",
        "scan_count":        0,
    }

    # ── DeepEval scores ───────────────────────────────────────────────────────
    deepeval = _load_json(_DEEPEVAL_JSON)
    if deepeval and isinstance(deepeval, list):
        by_metric: dict[str, list[float]] = {}
        for entry in deepeval:
            m = entry.get("metric_name", "")
            s = entry.get("score", 0.0)
            by_metric.setdefault(m, []).append(s)

        for metric, key in [
            ("faithfulness",  "faithfulness"),
            ("hallucination", "hallucination"),
            ("bias",          "bias"),
            ("toxicity",      "toxicity"),
            ("relevancy",     "relevancy"),
        ]:
            vals = by_metric.get(metric, [])
            if vals:
                scores[key] = round(sum(vals) / len(vals) * 100, 1)

        scores["last_scan"] = datetime.now().strftime("%Y-%m-%d")

    # ── Giskard scores ────────────────────────────────────────────────────────
    giskard = _load_json(_GISKARD_JSON)
    if giskard and isinstance(giskard, list):
        total  = len(giskard)
        passed = sum(1 for f in giskard if f.get("classification") == "false_positive")
        scores["security"] = round(passed / total * 100, 1) if total else 50.0
        scores["critical_issues"] += sum(
            1 for f in giskard
            if f.get("classification") == "true_positive" and f.get("severity") == "critical"
        )
        scores["medium_issues"] += sum(
            1 for f in giskard
            if f.get("classification") == "true_positive" and f.get("severity") == "high"
        )

    # ── Promptfoo scores ──────────────────────────────────────────────────────
    promptfoo = _load_json(_PROMPTFOO_JSON)
    if promptfoo and isinstance(promptfoo, dict):
        gov_stats = promptfoo.get("governed_stats", {})
        pass_rate = gov_stats.get("pass_rate", 0)
        scores["injection_resistance"] = float(pass_rate)
        scores["critical_issues"] += gov_stats.get("critical", 0)
        scores["medium_issues"]   += gov_stats.get("medium", 0)
        scores["low_issues"]      += gov_stats.get("low", 0)

    # ── Fairness scores ───────────────────────────────────────────────────────
    fairness = _load_json(_FAIRNESS_JSON)
    if fairness and isinstance(fairness, list):
        total = len(fairness)
        fair  = sum(1 for r in fairness if r.get("is_fair", True))
        scores["fairness"] = round(fair / total * 100, 1) if total else 50.0

    # ── Overall: weighted average of key metrics ──────────────────────────────
    weights = {
        "security":           0.20,
        "faithfulness":       0.15,
        "hallucination":      0.20,
        "bias":               0.15,
        "toxicity":           0.15,
        "injection_resistance": 0.15,
    }
    weighted = sum(scores[k] * w for k, w in weights.items())
    scores["overall"] = round(weighted, 1)

    # Fallback defaults if no data yet
    for key in scores:
        if isinstance(scores[key], float) and scores[key] == 0.0:
            scores[key] = 50.0  # neutral pending first scan

    return scores


# ─────────────────────────────────────────────────────────────────────────────
# Score colour helper
# ─────────────────────────────────────────────────────────────────────────────

def _score_color(score: float) -> str:
    if score >= 80:
        return "🟢"
    if score >= 60:
        return "🟡"
    return "🔴"


# ─────────────────────────────────────────────────────────────────────────────
# Main dashboard render function
# ─────────────────────────────────────────────────────────────────────────────

def render_governance_dashboard() -> None:
    """
    Render the full governance dashboard.
    Call this inside a Streamlit tab in app.py.
    """
    try:
        import streamlit as st
    except ImportError:
        logger.error("Streamlit not available.")
        return

    st.markdown("## 🛡️ AI Governance Dashboard")
    st.caption("BVRIT Chatbot — Governance Audit Results")

    scores = _compute_scores()

    # ── Section 1: KPI Score Cards ────────────────────────────────────────────
    st.markdown("### Overall Governance Scores")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric(
        f"{_score_color(scores['overall'])} Overall Score",
        f"{scores['overall']:.1f}%",
    )
    c2.metric(
        f"{_score_color(scores['security'])} Security",
        f"{scores['security']:.1f}%",
    )
    c3.metric(
        f"{_score_color(scores['fairness'])} Fairness",
        f"{scores['fairness']:.1f}%",
    )
    c4.metric(
        f"{_score_color(scores['hallucination'])} Hallucination",
        f"{scores['hallucination']:.1f}%",
    )

    c5, c6, c7, c8 = st.columns(4)
    c5.metric(
        f"{_score_color(scores['faithfulness'])} Faithfulness",
        f"{scores['faithfulness']:.1f}%",
    )
    c6.metric(
        f"{_score_color(scores['bias'])} Bias",
        f"{scores['bias']:.1f}%",
    )
    c7.metric(
        f"{_score_color(scores['toxicity'])} Toxicity",
        f"{scores['toxicity']:.1f}%",
    )
    c8.metric(
        f"{_score_color(scores['injection_resistance'])} Injection Resistance",
        f"{scores['injection_resistance']:.1f}%",
    )

    st.markdown("---")

    # ── Issue counts ──────────────────────────────────────────────────────────
    ic1, ic2, ic3, ic4 = st.columns(4)
    ic1.metric("🗓️ Last Scan",      scores["last_scan"])
    ic2.metric("🔴 Critical Issues", scores["critical_issues"])
    ic3.metric("🟡 Medium Issues",   scores["medium_issues"])
    ic4.metric("🟢 Low Issues",      scores["low_issues"])

    st.markdown("---")

    # ── Section 2: Charts ─────────────────────────────────────────────────────
    st.markdown("### 📊 Metric Visualisations")

    try:
        import pandas as pd

        chart_col1, chart_col2 = st.columns(2)

        # Bar chart of all metric scores
        with chart_col1:
            st.caption("Governance Scores by Category")
            metrics_df = pd.DataFrame({
                "Metric": ["Security", "Fairness", "Hallucination",
                           "Faithfulness", "Bias", "Toxicity",
                           "Injection Resistance"],
                "Score":  [
                    scores["security"], scores["fairness"],
                    scores["hallucination"], scores["faithfulness"],
                    scores["bias"], scores["toxicity"],
                    scores["injection_resistance"],
                ],
            }).set_index("Metric")
            st.bar_chart(metrics_df, use_container_width=True, height=300)

        # Pie chart for issue severity breakdown
        with chart_col2:
            st.caption("Issue Severity Breakdown")
            total_issues = (scores["critical_issues"] +
                            scores["medium_issues"] +
                            scores["low_issues"])
            if total_issues > 0:
                try:
                    import plotly.express as px
                    fig = px.pie(
                        values=[scores["critical_issues"],
                                scores["medium_issues"],
                                scores["low_issues"]],
                        names=["Critical", "Medium", "Low"],
                        color_discrete_sequence=["#ef4444", "#f59e0b", "#22c55e"],
                        hole=0.4,
                    )
                    fig.update_layout(margin=dict(t=10, b=10, l=10, r=10),
                                      height=300)
                    st.plotly_chart(fig, use_container_width=True)
                except ImportError:
                    sev_df = pd.DataFrame({
                        "Severity": ["Critical", "Medium", "Low"],
                        "Count":    [scores["critical_issues"],
                                     scores["medium_issues"],
                                     scores["low_issues"]],
                    }).set_index("Severity")
                    st.bar_chart(sev_df, use_container_width=True)
            else:
                st.success("✅ No issues recorded yet — run a scan first.")

    except ImportError:
        st.info("Install pandas for charts.")

    st.markdown("---")

    # ── Section 3: DeepEval findings table ───────────────────────────────────
    st.markdown("### 🔬 DeepEval Metric Details")
    deepeval_data = _load_json(_DEEPEVAL_JSON)
    if deepeval_data and isinstance(deepeval_data, list):
        try:
            import pandas as pd
            rows = []
            for e in deepeval_data:
                rows.append({
                    "Case":    e.get("case_id"),
                    "Dimension": e.get("dimension", ""),
                    "Metric":  e.get("metric_name", ""),
                    "Score":   round(e.get("score", 0.0), 3),
                    "Passed":  "✅" if e.get("passed") else "❌",
                    "Reason":  e.get("reason", "")[:80],
                })
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, height=320)
        except ImportError:
            st.json(deepeval_data[:5])
    else:
        st.info("No DeepEval results yet. Run: `python -m governance.deepeval_runner`")

    st.markdown("---")

    # ── Section 4: Giskard findings table ────────────────────────────────────
    st.markdown("### 🔍 Giskard Vulnerability Findings")
    giskard_data = _load_json(_GISKARD_JSON)
    if giskard_data and isinstance(giskard_data, list):
        try:
            import pandas as pd
            rows = []
            for f in giskard_data:
                rows.append({
                    "Detector":   f.get("detector", ""),
                    "Severity":   f.get("severity", "").upper(),
                    "Class":      f.get("classification", ""),
                    "Fixed":      "✅" if f.get("fix_applied") else "❌",
                    "Question":   f.get("question", "")[:60],
                    "Fix":        f.get("fix_description", "")[:80],
                })
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, height=280)
        except ImportError:
            st.json(giskard_data[:3])
    else:
        st.info("No Giskard results yet. Run: `python -m governance.giskard_runner`")

    st.markdown("---")

    # ── Section 5: Fairness findings ─────────────────────────────────────────
    st.markdown("### ⚖️ Fairness Audit Results")
    fairness_data = _load_json(_FAIRNESS_JSON)
    if fairness_data and isinstance(fairness_data, list):
        try:
            import pandas as pd
            rows = []
            for r in fairness_data:
                rows.append({
                    "ID":        r.get("test_id"),
                    "Persona":   r.get("persona"),
                    "Dimension": r.get("dimension"),
                    "Fair":      "✅" if r.get("is_fair") else "❌",
                    "Score":     round(r.get("bias_score", 0.0), 2),
                    "Issues":    "; ".join(r.get("issues", []))[:100],
                })
            df = pd.DataFrame(rows)
            st.dataframe(df, use_container_width=True, height=280)
        except ImportError:
            st.json(fairness_data[:3])
    else:
        st.info("No fairness results yet. Run: `python -m governance.fairness_tests`")

    st.markdown("---")

    # ── Section 6: Re-run buttons ─────────────────────────────────────────────
    st.markdown("### ▶️ Run Governance Scans")
    r1, r2, r3, r4 = st.columns(4)

    with r1:
        if st.button("🔍 Run Giskard Scan"):
            with st.spinner("Running Giskard scan…"):
                try:
                    from governance.giskard_runner import run_giskard_scan
                    findings = run_giskard_scan()
                    st.success(f"✅ Giskard: {len(findings)} probes completed.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Giskard failed: {e}")

    with r2:
        if st.button("🎯 Run Promptfoo Tests"):
            with st.spinner("Running Promptfoo tests…"):
                try:
                    from governance.promptfoo_runner import run_promptfoo_tests, generate_promptfoo_reports
                    legacy   = run_promptfoo_tests(governed=False)
                    governed = run_promptfoo_tests(governed=True)
                    generate_promptfoo_reports(legacy, governed)
                    st.success(f"✅ Promptfoo: {len(legacy)} tests completed.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Promptfoo failed: {e}")

    with r3:
        if st.button("📐 Run DeepEval"):
            with st.spinner("Running DeepEval metrics…"):
                try:
                    from governance.deepeval_runner import run_deepeval
                    results = run_deepeval(governed=True)
                    st.success(f"✅ DeepEval: {len(results)} evaluations.")
                    st.rerun()
                except Exception as e:
                    st.error(f"DeepEval failed: {e}")

    with r4:
        if st.button("⚖️ Run Fairness Audit"):
            with st.spinner("Running fairness tests…"):
                try:
                    from governance.fairness_tests import run_fairness_tests, generate_fairness_report
                    results = run_fairness_tests(governed=True)
                    generate_fairness_report(results)
                    st.success(f"✅ Fairness: {len(results)} tests completed.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Fairness audit failed: {e}")

    st.markdown("---")

    # ── Section 7: Download buttons ───────────────────────────────────────────
    st.markdown("### ⬇️ Download Reports")

    dl1, dl2, dl3, dl4, dl5 = st.columns(5)

    def _dl_btn(col, label: str, path: Path, mime: str = "text/markdown") -> None:
        with col:
            if path.exists():
                col.download_button(
                    label    = label,
                    data     = path.read_bytes(),
                    file_name= path.name,
                    mime     = mime,
                )
            else:
                col.caption(f"_{label.split()[1]} not generated yet_")

    _dl_btn(dl1, "📄 Governance Report",  _GOV_REPORT_MD)
    _dl_btn(dl2, "🔍 Giskard Report",     _GISKARD_MD)
    _dl_btn(dl3, "🎯 Promptfoo Report",   _PROMPTFOO_MD)
    _dl_btn(dl4, "📐 DeepEval Summary",   _DEEPEVAL_MD)
    _dl_btn(dl5, "⚖️ Fairness Report",    _FAIRNESS_MD)
