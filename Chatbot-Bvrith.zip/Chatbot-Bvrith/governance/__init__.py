"""
governance/__init__.py
======================
AI Governance Audit package for BVRIT Chatbot.

Modules
-------
governance_prompt   — Governance-hardened system prompt (6 pillars)
giskard_runner      — Giskard vulnerability scan (Exercise 1)
promptfoo_runner    — Promptfoo red-team runner (Exercise 2)
deepeval_runner     — DeepEval metric evaluation (Exercise 3)
fairness_tests      — Fairness & bias audit (Exercise 4)
governance_dashboard— Streamlit governance dashboard (Exercise 5)
"""

from governance.governance_prompt import (
    GOVERNANCE_SYSTEM_PROMPT,
    LEGACY_SYSTEM_PROMPT,
    get_governance_prompt,
    diff_prompts,
)

__all__ = [
    "GOVERNANCE_SYSTEM_PROMPT",
    "LEGACY_SYSTEM_PROMPT",
    "get_governance_prompt",
    "diff_prompts",
]
