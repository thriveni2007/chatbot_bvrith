"""
utils/prompt_testing.py
========================
Exercise 4 — Prompt A/B Testing
---------------------------------
Version A : the existing production system prompt (unchanged).
Version B : same prompt with a strict citation appendix added.

Assignment is random 50/50 per call.

Analytics function: compare_prompt_versions(logs) → dict with per-version
aggregated metrics.
"""

from __future__ import annotations

import random
from typing import Optional

# ── Prompt versions ───────────────────────────────────────────────────────────
# Version A — identical to the SYSTEM_PROMPT in rag_chain.py (no change)
PROMPT_VERSION_A_SUFFIX: str = ""   # nothing appended

# Version B — strict citation + uncertainty appendix
PROMPT_VERSION_B_SUFFIX: str = (
    "\n\n--- ADDITIONAL CITATION RULES (Version B) ---\n"
    "Cite [Section, Page] for every factual statement.\n"
    "If the exact answer does not exist in the retrieved context, respond:\n"
    "  'I don't have that specific information.'\n"
    "Never infer, assume or extrapolate beyond what is explicitly stated in CONTEXT."
)


def get_prompt_version() -> str:
    """
    Randomly assign A or B with 50 / 50 probability.
    Returns "A" or "B".
    """
    return "A" if random.random() < 0.5 else "B"


def get_prompt_suffix(version: str) -> str:
    """Return the suffix to append to the base system prompt for the given version."""
    if version == "B":
        return PROMPT_VERSION_B_SUFFIX
    return PROMPT_VERSION_A_SUFFIX


# ── Analytics ─────────────────────────────────────────────────────────────────
def _has_citation(text: str) -> bool:
    """Detect whether a response contains a [Section …] citation."""
    import re
    return bool(re.search(r"\[section\s+\d", text, re.IGNORECASE))


def _is_refusal(text: str) -> bool:
    """Detect whether the response is a knowledge-base refusal."""
    refusal_markers = [
        "i don't have that",
        "i don't have that specific information",
        "not in my knowledge base",
        "please contact bvrit",
        "i can only answer",
        "cannot guarantee",
        "i'm not sure what you're asking",
    ]
    lower = text.lower()
    return any(m in lower for m in refusal_markers)


def compare_prompt_versions(logs: list[dict]) -> dict:
    """
    Aggregate per-version metrics from a list of log-entry dicts.

    Returns
    -------
    {
        "A": {
            "count": int,
            "avg_latency": float,
            "avg_cost": float,
            "citation_rate": float,   # 0-1
            "refusal_rate": float,    # 0-1
            "success_rate": float,    # 0-1
            "avg_tokens": float,
        },
        "B": { ... same keys ... },
        "recommendation": str,
    }
    """
    buckets: dict[str, list[dict]] = {"A": [], "B": []}
    for entry in logs:
        v = entry.get("prompt_version", "A")
        if v in buckets:
            buckets[v].append(entry)

    result: dict = {}
    for version, entries in buckets.items():
        n = len(entries)
        if n == 0:
            result[version] = {
                "count": 0, "avg_latency": 0.0, "avg_cost": 0.0,
                "citation_rate": 0.0, "refusal_rate": 0.0,
                "success_rate": 0.0, "avg_tokens": 0.0,
            }
            continue

        avg_latency  = sum(e.get("latency_seconds", 0) for e in entries) / n
        avg_cost     = sum(e.get("estimated_cost_usd", 0) for e in entries) / n
        avg_tokens   = sum(e.get("total_tokens", 0) for e in entries) / n
        success_rate = sum(1 for e in entries if e.get("success", True)) / n
        citation_rate = sum(
            1 for e in entries if _has_citation(e.get("response_preview", ""))
        ) / n
        refusal_rate = sum(
            1 for e in entries if _is_refusal(e.get("response_preview", ""))
        ) / n

        result[version] = {
            "count":        n,
            "avg_latency":  round(avg_latency, 3),
            "avg_cost":     round(avg_cost, 6),
            "citation_rate": round(citation_rate, 3),
            "refusal_rate": round(refusal_rate, 3),
            "success_rate": round(success_rate, 3),
            "avg_tokens":   round(avg_tokens, 1),
        }

    # Simple recommendation
    a = result.get("A", {})
    b = result.get("B", {})
    recommendation = "Not enough data for a recommendation."
    if a.get("count", 0) >= 5 and b.get("count", 0) >= 5:
        if b.get("citation_rate", 0) > a.get("citation_rate", 0):
            recommendation = (
                "Version B shows higher citation rate — consider making it the default."
            )
        elif a.get("avg_latency", 99) < b.get("avg_latency", 99):
            recommendation = (
                "Version A is faster. Version B improves citations at a slight latency cost."
            )
        else:
            recommendation = "Versions A and B are performing similarly."

    result["recommendation"] = recommendation
    return result
