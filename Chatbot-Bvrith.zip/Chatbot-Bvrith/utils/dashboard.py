"""
utils/dashboard.py
==================
Exercise 2, 4 & 5 — Streamlit Dashboard Rendering
---------------------------------------------------
All Streamlit rendering logic lives here so that app.py stays thin.

Public API
----------
render_session_sidebar(logs)           — Exercise 2: live KPIs in the sidebar
render_log_table(logs)                 — Exercise 2: scrollable log table
render_ab_comparison(logs)             — Exercise 4: A/B prompt comparison
render_monitoring_dashboard(logs)      — Exercise 5: production monitoring tab
render_production_report(logs)         — Exercise 5: Markdown production report
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Optional

# Guard all streamlit imports so the module is importable in unit-test context
try:
    import streamlit as st
    _ST_AVAILABLE = True
except ImportError:  # pragma: no cover
    _ST_AVAILABLE = False

from utils.metrics import (
    compute_session_stats,
    compute_daily_stats,
    compute_hourly_traffic,
    compute_latency_histogram,
    detect_anomalies,
    gather_report_data,
    delta_from_previous,
)
from utils.prompt_testing import compare_prompt_versions


# ─────────────────────────────────────────────────────────────────────────────
# Exercise 2 — Session sidebar KPIs
# ─────────────────────────────────────────────────────────────────────────────

def render_session_sidebar(logs: list[dict]) -> None:
    """
    Render live session KPIs in the Streamlit sidebar.

    Shows: total queries, avg latency (+delta), total tokens, total cost,
    success rate, and a mini latency sparkline.
    """
    if not _ST_AVAILABLE:
        return

    stats = compute_session_stats(logs)

    st.sidebar.markdown("---")
    st.sidebar.markdown("### 📊 Session Metrics")

    col1, col2 = st.sidebar.columns(2)

    # Total queries
    col1.metric("Queries", stats["total_queries"])

    # Success rate
    col2.metric(
        "Success",
        f"{stats['success_rate']}%",
        delta=f"-{stats['error_count']} err" if stats["error_count"] else None,
        delta_color="inverse",
    )

    col3, col4 = st.sidebar.columns(2)

    # Avg latency with delta vs previous call
    lat_delta = delta_from_previous(logs, "latency_seconds")
    col3.metric(
        "Avg Latency",
        f"{stats['avg_latency']}s",
        delta=f"{lat_delta:+.2f}s" if lat_delta is not None else None,
        delta_color="inverse",  # lower is better
    )

    # P95 latency
    col4.metric("P95 Latency", f"{stats['p95_latency']}s")

    col5, col6 = st.sidebar.columns(2)

    # Total tokens
    col5.metric("Tokens", f"{stats['total_tokens']:,}")

    # Estimated cost
    col6.metric("Cost", f"${stats['total_cost']:.4f}")

    # Latency sparkline (last 20 calls)
    if stats["latency_trend"]:
        import pandas as pd
        trend = stats["latency_trend"][-20:]
        df = pd.DataFrame({"Latency (s)": trend})
        st.sidebar.caption("Latency trend (last 20 calls)")
        st.sidebar.line_chart(df, height=80, use_container_width=True)


# ─────────────────────────────────────────────────────────────────────────────
# Exercise 2 — Scrollable log table
# ─────────────────────────────────────────────────────────────────────────────

def render_log_table(logs: list[dict], max_rows: int = 50) -> None:
    """
    Render the recent call log as a formatted Streamlit dataframe.

    Columns: timestamp, query_id (short), user_query (truncated),
             model, tokens, latency, cost, version, success.
    """
    if not _ST_AVAILABLE:
        return

    if not logs:
        st.info("No LLM calls logged yet in this session.")
        return

    try:
        import pandas as pd
    except ImportError:
        st.warning("pandas not installed — cannot render log table.")
        return

    rows = []
    for e in logs[:max_rows]:
        ts = e.get("timestamp", "")
        # Shorten timestamp to HH:MM:SS for readability
        try:
            ts_short = datetime.fromisoformat(ts).strftime("%H:%M:%S")
        except Exception:
            ts_short = ts[:19]

        rows.append({
            "Time":     ts_short,
            "ID":       e.get("query_id", "")[:8],
            "Query":    e.get("user_query", "")[:60],
            "Model":    e.get("model_name", ""),
            "Tokens":   e.get("total_tokens", 0),
            "Latency":  f"{e.get('latency_seconds', 0):.2f}s",
            "Cost":     f"${e.get('estimated_cost_usd', 0):.5f}",
            "Ver":      e.get("prompt_version", "A"),
            "✓":        "✅" if e.get("success", True) else "❌",
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, height=min(400, 40 + len(rows) * 35))


# ─────────────────────────────────────────────────────────────────────────────
# Exercise 4 — A/B Prompt comparison
# ─────────────────────────────────────────────────────────────────────────────

def render_ab_comparison(logs: list[dict]) -> None:
    """
    Render the A/B prompt performance comparison section.

    Shows per-version: call count, avg latency, avg cost, citation rate,
    refusal rate, success rate, avg tokens — plus a recommendation banner.
    """
    if not _ST_AVAILABLE:
        return

    st.subheader("🔬 Prompt A/B Testing")

    result = compare_prompt_versions(logs)

    col_a, col_b = st.columns(2)

    for col, version, label in [
        (col_a, "A", "Version A — Production"),
        (col_b, "B", "Version B — Citation+"),
    ]:
        data = result.get(version, {})
        with col:
            st.markdown(f"**{label}**")
            st.metric("Calls",        data.get("count", 0))
            st.metric("Avg Latency",  f"{data.get('avg_latency', 0):.2f}s")
            st.metric("Avg Cost",     f"${data.get('avg_cost', 0):.5f}")
            st.metric("Citation Rate", f"{data.get('citation_rate', 0)*100:.1f}%")
            st.metric("Refusal Rate",  f"{data.get('refusal_rate', 0)*100:.1f}%")
            st.metric("Success Rate",  f"{data.get('success_rate', 0)*100:.1f}%")
            st.metric("Avg Tokens",    f"{data.get('avg_tokens', 0):.0f}")

    recommendation = result.get("recommendation", "")
    if recommendation:
        st.info(f"💡 **Recommendation:** {recommendation}")

    # Raw data expander
    with st.expander("📋 Raw A/B data (JSON)"):
        st.json({k: v for k, v in result.items() if k != "recommendation"})


# ─────────────────────────────────────────────────────────────────────────────
# Exercise 5 — Production monitoring dashboard
# ─────────────────────────────────────────────────────────────────────────────

def render_monitoring_dashboard(logs: list[dict]) -> None:
    """
    Render the full production-monitoring section.

    Sections:
      1. KPI headline row (total queries, error rate, total cost, avg latency)
      2. Daily traffic + cost line chart
      3. Hourly traffic bar chart
      4. Latency histogram
      5. Anomaly alerts
      6. Top-5 most expensive calls
    """
    if not _ST_AVAILABLE:
        return

    st.subheader("🖥️ Production Monitoring")

    if not logs:
        st.info("No logs yet — run some queries first.")
        return

    try:
        import pandas as pd
    except ImportError:
        st.warning("pandas not installed — charts unavailable.")
        return

    stats = compute_session_stats(logs)

    # ── KPI headline row ──────────────────────────────────────────────────────
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Total Queries",  stats["total_queries"])
    k2.metric("Error Rate",     f"{100 - stats['success_rate']:.1f}%",
              delta=f"{stats['error_count']} errors", delta_color="inverse")
    k3.metric("Total Cost",     f"${stats['total_cost']:.4f}")
    k4.metric("Avg Latency",    f"{stats['avg_latency']}s")

    st.markdown("---")

    # ── Daily traffic & cost ──────────────────────────────────────────────────
    daily = compute_daily_stats(logs)
    if daily:
        df_daily = pd.DataFrame(daily).T.reset_index()
        df_daily.rename(columns={"index": "date"}, inplace=True)
        df_daily["queries"] = pd.to_numeric(df_daily["queries"])
        df_daily["cost"]    = pd.to_numeric(df_daily["cost"])

        col_left, col_right = st.columns(2)
        with col_left:
            st.caption("📅 Daily query volume")
            st.bar_chart(df_daily.set_index("date")["queries"], use_container_width=True)
        with col_right:
            st.caption("💸 Daily cost (USD)")
            st.line_chart(df_daily.set_index("date")["cost"], use_container_width=True)

    st.markdown("---")

    # ── Hourly traffic ────────────────────────────────────────────────────────
    hourly = compute_hourly_traffic(logs)
    df_hourly = pd.DataFrame(
        [{"hour": k, "queries": v} for k, v in hourly.items()]
    ).set_index("hour")
    st.caption("🕐 Hourly query distribution (UTC)")
    st.bar_chart(df_hourly, use_container_width=True, height=200)

    st.markdown("---")

    # ── Latency histogram ─────────────────────────────────────────────────────
    hist = compute_latency_histogram(logs)
    if hist["counts"]:
        edges  = hist["bin_edges"]
        counts = hist["counts"]
        labels = [f"{edges[i]:.1f}-{edges[i+1]:.1f}s" for i in range(len(counts))]
        df_hist = pd.DataFrame({"Latency bucket": labels, "Count": counts}).set_index("Latency bucket")
        st.caption("⏱️ Latency distribution")
        st.bar_chart(df_hist, use_container_width=True, height=200)

    st.markdown("---")

    # ── Anomaly alerts ────────────────────────────────────────────────────────
    anomalies = detect_anomalies(logs)
    st.caption("🚨 Anomaly Detection (last 10 calls)")
    if anomalies:
        for a in anomalies:
            if "spike" in a["type"] or "burst" in a["type"]:
                st.error(f"**{a['type'].replace('_', ' ').title()}** — {a['message']}")
            else:
                st.warning(f"**{a['type'].replace('_', ' ').title()}** — {a['message']}")
    else:
        st.success("✅ No anomalies detected in the most recent calls.")

    st.markdown("---")

    # ── Top-5 most expensive calls ────────────────────────────────────────────
    st.caption("💰 Top 5 Most Expensive Calls")
    top5 = stats.get("top5_expensive", [])
    if top5:
        rows = []
        for e in top5:
            rows.append({
                "Query":    e.get("user_query", "")[:60],
                "Tokens":   e.get("total_tokens", 0),
                "Cost":     f"${e.get('estimated_cost_usd', 0):.5f}",
                "Latency":  f"{e.get('latency_seconds', 0):.2f}s",
                "Model":    e.get("model_name", ""),
            })
        st.dataframe(pd.DataFrame(rows), use_container_width=True)
    else:
        st.info("No data yet.")


# ─────────────────────────────────────────────────────────────────────────────
# Exercise 5 — Markdown production report
# ─────────────────────────────────────────────────────────────────────────────

def render_production_report(logs: list[dict]) -> None:
    """
    Render a structured Markdown production report inside a Streamlit expander.
    Also provides a download button for the raw JSON report data.
    """
    if not _ST_AVAILABLE:
        return

    with st.expander("📄 Production Report", expanded=False):
        data = gather_report_data(logs)

        if "error" in data:
            st.warning(data["error"])
            return

        stats     = data["stats"]
        daily     = data["daily"]
        anomalies = data["anomalies"]
        slowest   = data.get("slowest", {})
        costliest = data.get("costliest", {})

        report_md = f"""
## 📊 BVRIT Chatbot — Production Report

**Generated:** {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}

---

### Summary KPIs
| Metric | Value |
|--------|-------|
| Total Queries | {stats['total_queries']} |
| Avg Latency | {stats['avg_latency']}s |
| P95 Latency | {stats['p95_latency']}s |
| Max Latency | {stats['max_latency']}s |
| Total Tokens | {stats['total_tokens']:,} |
| Total Cost | ${stats['total_cost']:.6f} |
| Error Count | {stats['error_count']} |
| Success Rate | {stats['success_rate']}% |

---

### Daily Breakdown
| Date | Queries | Cost | Errors | Avg Latency |
|------|---------|------|--------|-------------|
"""
        for day, d in daily.items():
            report_md += (
                f"| {day} | {d['queries']} | ${d['cost']:.5f} "
                f"| {d['errors']} | {d['avg_latency']}s |\n"
            )

        report_md += "\n---\n\n### Anomalies\n"
        if anomalies:
            for a in anomalies:
                report_md += f"- **{a['type']}**: {a['message']}\n"
        else:
            report_md += "_No anomalies detected._\n"

        if slowest:
            report_md += f"""
---

### Slowest Call
- **Query:** {slowest.get('user_query', 'N/A')[:100]}
- **Latency:** {slowest.get('latency_seconds', 0):.2f}s
- **Tokens:** {slowest.get('total_tokens', 0):,}
- **ID:** `{slowest.get('query_id', 'N/A')[:8]}`
"""

        if costliest:
            report_md += f"""
### Most Expensive Call
- **Query:** {costliest.get('user_query', 'N/A')[:100]}
- **Cost:** ${costliest.get('estimated_cost_usd', 0):.6f}
- **Tokens:** {costliest.get('total_tokens', 0):,}
- **ID:** `{costliest.get('query_id', 'N/A')[:8]}`
"""

        st.markdown(report_md)

        # Download button for raw JSON
        st.download_button(
            label="⬇️ Download Report (JSON)",
            data=json.dumps(data, indent=2, default=str),
            file_name="bvrit_production_report.json",
            mime="application/json",
        )
