"""
utils/logging_utils.py
======================
Exercise 1 — Centralized LLM Observability Logger
--------------------------------------------------
Every LLM invocation in the project must go through `logged_llm_call()`.

Records per call:
  timestamp, query_id, user_query, model_name,
  input_tokens, output_tokens, total_tokens,
  latency_seconds, estimated_cost_usd,
  prompt_version (A/B), success/failure,
  error_message, response_preview (first 150 chars)

Persistent store : logs/session_logs.jsonl
Session store    : st.session_state.logs  (list of dicts)
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

# ── Standard library logger (separate from LLM logs) ─────────────────────────
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR  = Path(__file__).resolve().parent.parent
LOGS_DIR  = BASE_DIR / "logs"
LOGS_FILE = LOGS_DIR / "session_logs.jsonl"

LOGS_DIR.mkdir(parents=True, exist_ok=True)

# ── Cost table (USD per 1 000 tokens) ─────────────────────────────────────────
# Groq free-tier pricing is effectively $0 but we estimate as if using paid tier
# so alerts fire correctly in a real-money environment.
_COST_TABLE: dict[str, dict[str, float]] = {
    "llama-3.3-70b-versatile":   {"input": 0.00059, "output": 0.00079},
    "llama3-8b-8192":            {"input": 0.00005, "output": 0.00008},
    "llama3-70b-8192":           {"input": 0.00059, "output": 0.00079},
    "mixtral-8x7b-32768":        {"input": 0.00024, "output": 0.00024},
    "gemma2-9b-it":              {"input": 0.00020, "output": 0.00020},
    # default fallback
    "default":                   {"input": 0.00059, "output": 0.00079},
}

# Average chars-per-token (rough heuristic for non-tiktoken environments)
_CHARS_PER_TOKEN = 4.0


# ── Dataclass for one log entry ───────────────────────────────────────────────
@dataclass
class LLMLogEntry:
    query_id:          str
    timestamp:         str
    user_query:        str
    model_name:        str
    input_tokens:      int
    output_tokens:     int
    total_tokens:      int
    latency_seconds:   float
    estimated_cost_usd: float
    prompt_version:    str          # "A" or "B"
    success:           bool
    error_message:     str
    response_preview:  str          # first 150 chars of answer
    extra:             dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


# ── Token & cost helpers ───────────────────────────────────────────────────────
def estimate_tokens(text: str) -> int:
    """Estimate token count from character length (fast, no external lib needed)."""
    if not text:
        return 0
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except Exception:
        return max(1, int(len(text) / _CHARS_PER_TOKEN))


def calculate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Return estimated USD cost for the given token counts."""
    rates = _COST_TABLE.get(model, _COST_TABLE["default"])
    cost = (input_tokens * rates["input"] + output_tokens * rates["output"]) / 1_000
    return round(cost, 8)


# ── Disk helpers ──────────────────────────────────────────────────────────────
def append_log(entry: LLMLogEntry) -> None:
    """Append one log entry as a JSON line to session_logs.jsonl."""
    try:
        with open(LOGS_FILE, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")
    except Exception as exc:
        logger.warning("append_log failed: %s", exc)


def load_logs(limit: Optional[int] = None) -> list[dict]:
    """
    Load all logs from session_logs.jsonl.
    Returns newest-first. Pass `limit` to cap results.
    """
    if not LOGS_FILE.exists():
        return []
    entries: list[dict] = []
    try:
        with open(LOGS_FILE, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    except Exception as exc:
        logger.warning("load_logs failed: %s", exc)
        return []

    # newest first
    entries.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return entries[:limit] if limit else entries


# ── Session state integration ─────────────────────────────────────────────────
def _get_session_logs() -> list[dict]:
    """Return or initialize st.session_state.logs (import-safe)."""
    try:
        import streamlit as st
        if "logs" not in st.session_state:
            st.session_state.logs = []
        return st.session_state.logs
    except Exception:
        return []


def _append_session_log(entry: LLMLogEntry) -> None:
    """Push entry dict into st.session_state.logs."""
    try:
        logs = _get_session_logs()
        logs.append(entry.to_dict())
    except Exception as exc:
        logger.debug("_append_session_log failed (no Streamlit context): %s", exc)


# ── Core wrapper ──────────────────────────────────────────────────────────────
def logged_llm_call(
    llm_callable: Callable[..., Any],
    prompt_text: str,
    user_query: str = "",
    model_name: str = "",
    prompt_version: str = "A",
    extra: Optional[dict] = None,
    *args: Any,
    **kwargs: Any,
) -> tuple[Any, LLMLogEntry]:
    """
    Universal LLM call wrapper.

    Parameters
    ----------
    llm_callable  : Any callable that performs the LLM call and returns a
                    result with a `.content` attribute (LangChain AIMessage)
                    OR a plain string.
    prompt_text   : The full prompt / messages string sent to the LLM.
    user_query    : The original human question (for display in dashboards).
    model_name    : LLM model identifier (e.g. "llama-3.3-70b-versatile").
    prompt_version: "A" or "B" (for A/B testing).
    extra         : Any additional key-value metadata to store.
    *args, **kwargs: Passed through to llm_callable.

    Returns
    -------
    (result, log_entry) — the raw LLM result and the LLMLogEntry dataclass.
    """
    query_id     = str(uuid.uuid4())
    timestamp    = datetime.now(timezone.utc).isoformat()
    input_tokens = estimate_tokens(prompt_text)

    start   = time.perf_counter()
    success = True
    error_message    = ""
    response_content = ""
    result           = None

    try:
        result = llm_callable(*args, **kwargs)
        # Extract string content from LangChain AIMessage or plain string
        if hasattr(result, "content"):
            response_content = result.content or ""
        elif isinstance(result, str):
            response_content = result
        else:
            response_content = str(result)
    except Exception as exc:
        success          = False
        error_message    = str(exc)[:500]
        response_content = ""
        logger.error("LLM call failed [%s]: %s", query_id, error_message)
        raise  # re-raise so callers still get the exception
    finally:
        latency       = round(time.perf_counter() - start, 3)
        output_tokens = estimate_tokens(response_content)
        total_tokens  = input_tokens + output_tokens
        cost          = calculate_cost(model_name, input_tokens, output_tokens)

        entry = LLMLogEntry(
            query_id           = query_id,
            timestamp          = timestamp,
            user_query         = user_query[:300],
            model_name         = model_name,
            input_tokens       = input_tokens,
            output_tokens      = output_tokens,
            total_tokens       = total_tokens,
            latency_seconds    = latency,
            estimated_cost_usd = cost,
            prompt_version     = prompt_version,
            success            = success,
            error_message      = error_message,
            response_preview   = response_content[:150],
            extra              = extra or {},
        )

        append_log(entry)
        _append_session_log(entry)
        logger.info(
            "LLM[%s] model=%s tokens=%d latency=%.2fs cost=$%.6f success=%s",
            query_id[:8], model_name, total_tokens, latency, cost, success,
        )

    return result, entry


# ── Convenience: wrap a LangChain chain.invoke call ──────────────────────────
def logged_chain_invoke(
    chain: Any,
    inputs: dict,
    user_query: str = "",
    model_name: str = "",
    prompt_version: str = "A",
    extra: Optional[dict] = None,
) -> tuple[Any, LLMLogEntry]:
    """
    Thin wrapper around `chain.invoke(inputs)` that logs the call.
    `inputs` is also serialised as the prompt_text for token estimation.
    """
    prompt_text = json.dumps(inputs, ensure_ascii=False)
    return logged_llm_call(
        llm_callable   = lambda: chain.invoke(inputs),
        prompt_text    = prompt_text,
        user_query     = user_query,
        model_name     = model_name,
        prompt_version = prompt_version,
        extra          = extra,
    )
