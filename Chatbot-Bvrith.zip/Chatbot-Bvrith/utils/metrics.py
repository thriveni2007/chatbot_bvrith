"""
utils/metrics.py
================
Exercise 2 & 5 — Metric Computation Helpers
--------------------------------------------
Pure-computation functions that take a list of log-entry dicts and return
aggregated statistics.  No Streamlit imports here — keeps it testable.
"""

from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any, Optional


# ── Session / sidebar metrics (Exercise 2) ───────────────────────────────────
def compute_session_stats(logs: list[dict]) -> dict:
    """
    Compute aggregate stats over a list of log-entry dicts.

    Returns
    -------
    {
      total_queries, avg_latency, p95_latency, max_latency,
      total_tokens, input_tokens, output_tokens,
      total_cost, error_count, success_rate,
      latency_trend  : list[float]   (all latencies in order)
      top5_expensive : list[dict]    (sorted by cost desc)
      last10         : list[dict]    (most-recent 10)
    }
    """
    if not logs:
        return _empty_stats()

    latencies   = [e.get("latency_seconds", 0.0)    for e in logs]
    costs       = [e.get("estimated_cost_usd", 0.0) for e in logs]
    in_tok      = [e.get("input_tokens", 0)         for e in logs]
    out_tok     = [e.get("output_tokens", 0)        for e in logs]
    total_tok   = [e.get("total_tokens", 0)         for e in logs]
    successes   = [bool(e.get("success", True))     for e in logs]

    n           = len(logs)
    error_count = successes.count(False)

    # P95 latency
    sorted_lat  = sorted(latencies)
    p95_idx     = max(0, int(0.95 * n) - 1)
    p95_lat     = sorted_lat[p95_idx] if sorted_lat else 0.0

    # Top 5 most expensive
    top5 = sorted(logs, key=lambda e: e.get("estimated_cost_usd", 0.0), reverse=True)[:5]

    # Last 10 (newest first — already newest-first from load_logs; reverse for recency)
    last10 = logs[:10]

    return {
        "total_queries":  n,
        "avg_latency":    round(statistics.mean(latencies), 3) if latencies else 0.0,
        "p95_latency":    round(p95_lat, 3),
        "max_latency":    round(max(latencies), 3) if latencies else 0.0,
        "total_tokens":   sum(total_tok),
        "input_tokens":   sum(in_tok),
        "output_tokens":  sum(out_tok),
        "total_cost":     round(sum(costs), 6),
        "error_count":    error_count,
        "success_rate":   round((n - error_count) / n * 100, 1) if n else 0.0,
        "latency_trend":  latencies,      # chronological order for line_chart
        "top5_expensive": top5,
        "last10":         last10,
    }


def _empty_stats() -> dict:
    return {
        "total_queries": 0, "avg_latency": 0.0, "p95_latency": 0.0,
        "max_latency": 0.0, "total_tokens": 0, "input_tokens": 0,
        "output_tokens": 0, "total_cost": 0.0, "error_count": 0,
        "success_rate": 0.0, "latency_trend": [],
        "top5_expensive": [], "last10": [],
    }


def delta_from_previous(logs: list[dict], key: str) -> Optional[float]:
    """
    Return the change between the last two values of `key` in the logs.
    Used for st.metric delta argument.
    """
    values = [e.get(key) for e in logs if e.get(key) is not None]
    if len(values) < 2:
        return None
    return round(float(values[0]) - float(values[1]), 4)


# ── Daily / monitoring metrics (Exercise 5) ──────────────────────────────────
def _parse_ts(ts_str: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(ts_str)
    except Exception:
        return None


def compute_daily_stats(logs: list[dict]) -> dict:
    """
    Group logs by UTC date (YYYY-MM-DD) and compute per-day aggregates.

    Returns
    -------
    {
      "YYYY-MM-DD": {
        queries, cost, errors, avg_latency, tokens
      }, ...
    }
    Sorted chronologically.
    """
    by_day: dict[str, list[dict]] = defaultdict(list)
    for e in logs:
        dt = _parse_ts(e.get("timestamp", ""))
        if dt:
            day_key = dt.strftime("%Y-%m-%d")
            by_day[day_key].append(e)

    result: dict = {}
    for day in sorted(by_day.keys()):
        entries = by_day[day]
        lats    = [x.get("latency_seconds", 0.0) for x in entries]
        result[day] = {
            "queries":     len(entries),
            "cost":        round(sum(x.get("estimated_cost_usd", 0.0) for x in entries), 6),
            "errors":      sum(1 for x in entries if not x.get("success", True)),
            "avg_latency": round(statistics.mean(lats), 3) if lats else 0.0,
            "tokens":      sum(x.get("total_tokens", 0) for x in entries),
        }
    return result


def compute_hourly_traffic(logs: list[dict]) -> dict[str, int]:
    """
    Count queries per UTC hour (HH:00) across all logs.
    Returns dict {"00": count, "01": count, ..., "23": count}.
    """
    counts: dict[str, int] = {f"{h:02d}": 0 for h in range(24)}
    for e in logs:
        dt = _parse_ts(e.get("timestamp", ""))
        if dt:
            counts[f"{dt.hour:02d}"] += 1
    return counts


def compute_latency_histogram(logs: list[dict], bins: int = 10) -> dict:
    """
    Compute a latency histogram suitable for st.bar_chart / plotly.

    Returns {"bin_edges": [...], "counts": [...]}
    """
    latencies = [e.get("latency_seconds", 0.0) for e in logs if e.get("latency_seconds") is not None]
    if not latencies:
        return {"bin_edges": [], "counts": []}

    min_l = min(latencies)
    max_l = max(latencies) + 0.001  # avoid right-edge miss
    width = (max_l - min_l) / bins
    edges = [round(min_l + i * width, 2) for i in range(bins + 1)]
    counts = [0] * bins
    for val in latencies:
        idx = min(int((val - min_l) / width), bins - 1)
        counts[idx] += 1
    return {"bin_edges": edges, "counts": counts}


# ── Anomaly detection (Exercise 5) ───────────────────────────────────────────
def detect_anomalies(logs: list[dict], window: int = 10) -> list[dict]:
    """
    Scan the most-recent `window` log entries for anomalies.

    Detects:
      - unusually high token usage  (> mean + 2*stdev)
      - latency spike               (> mean + 2*stdev)
      - error spike                 (>30 % errors in window)
      - rate-limit burst            (2+ rate-limit errors in window)

    Returns a list of anomaly dicts: {type, message, value, entry_id}
    """
    recent = logs[:window]
    if len(recent) < 3:
        return []

    anomalies: list[dict] = []

    # ── Token anomaly ─────────────────────────────────────────────────────────
    tokens = [e.get("total_tokens", 0) for e in recent]
    if len(tokens) >= 3:
        mean_t = statistics.mean(tokens)
        std_t  = statistics.stdev(tokens) if len(tokens) > 1 else 0
        threshold_t = mean_t + 2 * std_t
        for e in recent:
            if e.get("total_tokens", 0) > threshold_t and threshold_t > 0:
                anomalies.append({
                    "type":     "high_token_usage",
                    "message":  f"Token spike: {e['total_tokens']:,} tokens (threshold {threshold_t:.0f})",
                    "value":    e["total_tokens"],
                    "entry_id": e.get("query_id", ""),
                })

    # ── Latency spike ─────────────────────────────────────────────────────────
    lats = [e.get("latency_seconds", 0.0) for e in recent]
    if len(lats) >= 3:
        mean_l = statistics.mean(lats)
        std_l  = statistics.stdev(lats) if len(lats) > 1 else 0
        threshold_l = mean_l + 2 * std_l
        for e in recent:
            lat = e.get("latency_seconds", 0.0)
            if lat > threshold_l and threshold_l > 0:
                anomalies.append({
                    "type":     "latency_spike",
                    "message":  f"Latency spike: {lat:.2f}s (threshold {threshold_l:.2f}s)",
                    "value":    lat,
                    "entry_id": e.get("query_id", ""),
                })

    # ── Error spike ───────────────────────────────────────────────────────────
    err_count = sum(1 for e in recent if not e.get("success", True))
    err_rate  = err_count / len(recent)
    if err_rate > 0.30:
        anomalies.append({
            "type":     "error_spike",
            "message":  f"Error spike: {err_rate*100:.0f}% failures in last {len(recent)} calls",
            "value":    err_rate,
            "entry_id": "",
        })

    # ── Rate-limit burst ──────────────────────────────────────────────────────
    rl_count = sum(
        1 for e in recent
        if "429" in e.get("error_message", "") or "rate_limit" in e.get("error_message", "").lower()
    )
    if rl_count >= 2:
        anomalies.append({
            "type":     "rate_limit_burst",
            "message":  f"Rate-limit burst: {rl_count} rate-limit errors in last {len(recent)} calls",
            "value":    rl_count,
            "entry_id": "",
        })

    return anomalies


# ── Production Report data gathering (Exercise 5) ────────────────────────────
def gather_report_data(logs: list[dict]) -> dict:
    """
    Collect all stats needed for the Markdown production report.
    """
    if not logs:
        return {"error": "No logs available."}

    stats       = compute_session_stats(logs)
    daily       = compute_daily_stats(logs)
    anomalies   = detect_anomalies(logs)

    # Worst / slowest / most expensive individual queries
    slowest    = max(logs, key=lambda e: e.get("latency_seconds", 0.0), default={})
    costliest  = max(logs, key=lambda e: e.get("estimated_cost_usd", 0.0), default={})
    error_logs = [e for e in logs if not e.get("success", True)]

    return {
        "stats":       stats,
        "daily":       daily,
        "anomalies":   anomalies,
        "slowest":     slowest,
        "costliest":   costliest,
        "error_count": len(error_logs),
    }
