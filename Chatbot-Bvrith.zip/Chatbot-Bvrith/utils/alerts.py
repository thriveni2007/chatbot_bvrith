"""
utils/alerts.py
===============
Exercise 3 — Production Alerting
---------------------------------
Threshold-based alert system for the BVRIT Chatbot.

Thresholds
----------
LATENCY_THRESHOLD_S   : 10 seconds
COST_THRESHOLD_USD    : $0.10 per call
ERROR_RATE_THRESHOLD  : 5 % rolling (last 20 calls)
INPUT_LENGTH_THRESHOLD: 2 000 characters
TOKEN_THRESHOLD       : 8 000 tokens total

Each alert:
 - Displays a Streamlit st.warning() / st.error()
 - Logs the alert event to logs/alerts.jsonl
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).resolve().parent.parent
LOGS_DIR    = BASE_DIR / "logs"
ALERTS_FILE = LOGS_DIR / "alerts.jsonl"
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# ── Thresholds (no hard-coded magic numbers) ──────────────────────────────────
LATENCY_THRESHOLD_S    : float = 10.0
COST_THRESHOLD_USD     : float = 0.10
ERROR_RATE_THRESHOLD   : float = 0.05   # 5 %
INPUT_LENGTH_THRESHOLD : int   = 2_000  # characters
TOKEN_THRESHOLD        : int   = 8_000  # total tokens
ROLLING_WINDOW         : int   = 20     # calls to consider for error-rate


# ── Internal helpers ──────────────────────────────────────────────────────────
def _log_alert(alert_type: str, message: str, value: float | int | str) -> None:
    """Persist an alert event to logs/alerts.jsonl."""
    event = {
        "timestamp":  datetime.now(timezone.utc).isoformat(),
        "alert_type": alert_type,
        "message":    message,
        "value":      value,
    }
    try:
        with open(ALERTS_FILE, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False) + "\n")
    except Exception as exc:
        logger.warning("_log_alert write failed: %s", exc)


def _show(level: str, message: str) -> None:
    """Display alert in Streamlit if available, else log."""
    try:
        import streamlit as st
        if level == "error":
            st.error(f"🚨 **ALERT** — {message}")
        else:
            st.warning(f"⚠️ **WARNING** — {message}")
    except Exception:
        if level == "error":
            logger.error("ALERT: %s", message)
        else:
            logger.warning("WARNING: %s", message)


# ── Public alert functions ────────────────────────────────────────────────────
def check_latency_alert(latency_seconds: float) -> bool:
    """
    Fire an alert if the call exceeded LATENCY_THRESHOLD_S.
    Returns True if alert was triggered.
    """
    if latency_seconds > LATENCY_THRESHOLD_S:
        msg = (
            f"Response latency {latency_seconds:.1f}s exceeded threshold "
            f"of {LATENCY_THRESHOLD_S}s. Consider optimising retrieval."
        )
        _show("warning", msg)
        _log_alert("high_latency", msg, latency_seconds)
        return True
    return False


def check_cost_alert(cost_usd: float) -> bool:
    """
    Fire an alert if the estimated cost exceeded COST_THRESHOLD_USD.
    Returns True if alert was triggered.
    """
    if cost_usd > COST_THRESHOLD_USD:
        msg = (
            f"Estimated cost ${cost_usd:.4f} exceeded threshold "
            f"of ${COST_THRESHOLD_USD:.2f}."
        )
        _show("error", msg)
        _log_alert("high_cost", msg, cost_usd)
        return True
    return False


def check_error_rate_alert(session_logs: list[dict]) -> bool:
    """
    Check the rolling error rate over the last ROLLING_WINDOW calls.
    Returns True if alert was triggered.
    """
    recent = session_logs[-ROLLING_WINDOW:] if len(session_logs) >= ROLLING_WINDOW else session_logs
    if not recent:
        return False
    error_count = sum(1 for e in recent if not e.get("success", True))
    error_rate  = error_count / len(recent)
    if error_rate > ERROR_RATE_THRESHOLD:
        msg = (
            f"Rolling error rate {error_rate*100:.1f}% (last {len(recent)} calls) "
            f"exceeded threshold of {ERROR_RATE_THRESHOLD*100:.0f}%."
        )
        _show("error", msg)
        _log_alert("high_error_rate", msg, round(error_rate, 4))
        return True
    return False


def check_token_alert(total_tokens: int) -> bool:
    """
    Fire an alert if total tokens in a call exceeded TOKEN_THRESHOLD.
    Returns True if alert was triggered.
    """
    if total_tokens > TOKEN_THRESHOLD:
        msg = (
            f"Total tokens {total_tokens:,} exceeded threshold of {TOKEN_THRESHOLD:,}. "
            "Consider shortening context or history."
        )
        _show("warning", msg)
        _log_alert("high_token_count", msg, total_tokens)
        return True
    return False


def check_input_length(user_input: str) -> Optional[str]:
    """
    Validate user input length.
    Returns a rejection message string if too long, else None.
    Logs rejected requests.
    """
    if len(user_input) > INPUT_LENGTH_THRESHOLD:
        msg = (
            "Your message is too large. Please shorten your question "
            "or upload the document separately."
        )
        _log_alert(
            "input_too_long",
            f"User input rejected — {len(user_input)} chars exceeded {INPUT_LENGTH_THRESHOLD}.",
            len(user_input),
        )
        logger.warning("Input rejected: %d chars", len(user_input))
        return msg
    return None


def run_all_post_call_checks(log_entry_dict: dict, session_logs: list[dict]) -> None:
    """
    Convenience function — run every post-call alert check given a single
    log entry (as dict) and the full session log list.
    Call this once after every LLM invocation completes.
    """
    check_latency_alert(log_entry_dict.get("latency_seconds", 0.0))
    check_cost_alert(log_entry_dict.get("estimated_cost_usd", 0.0))
    check_token_alert(log_entry_dict.get("total_tokens", 0))
    check_error_rate_alert(session_logs)


def load_alert_log() -> list[dict]:
    """Load all historical alert events from alerts.jsonl."""
    if not ALERTS_FILE.exists():
        return []
    events: list[dict] = []
    try:
        with open(ALERTS_FILE, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
    except Exception as exc:
        logger.warning("load_alert_log failed: %s", exc)
    return events
