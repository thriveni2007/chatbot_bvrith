"""
utils/__init__.py
=================
Production Observability Package for BVRIT Chatbot.

Re-exports the public API of every submodule so callers can do:

    from utils import logged_llm_call, render_session_sidebar, ...

or import the submodule directly:

    from utils.logging_utils import logged_llm_call
"""

# ── Exercise 1: LLM logging ───────────────────────────────────────────────────
from utils.logging_utils import (
    LLMLogEntry,
    logged_llm_call,
    logged_chain_invoke,
    load_logs,
    append_log,
    estimate_tokens,
    calculate_cost,
)

# ── Exercise 3: Alerts ────────────────────────────────────────────────────────
from utils.alerts import (
    check_latency_alert,
    check_cost_alert,
    check_error_rate_alert,
    check_token_alert,
    check_input_length,
    run_all_post_call_checks,
    load_alert_log,
    LATENCY_THRESHOLD_S,
    COST_THRESHOLD_USD,
    ERROR_RATE_THRESHOLD,
    INPUT_LENGTH_THRESHOLD,
    TOKEN_THRESHOLD,
)

# ── Exercise 4: Prompt A/B testing ───────────────────────────────────────────
from utils.prompt_testing import (
    get_prompt_version,
    get_prompt_suffix,
    compare_prompt_versions,
    PROMPT_VERSION_A_SUFFIX,
    PROMPT_VERSION_B_SUFFIX,
)

# ── Exercise 2 & 5: Metrics ───────────────────────────────────────────────────
from utils.metrics import (
    compute_session_stats,
    compute_daily_stats,
    compute_hourly_traffic,
    compute_latency_histogram,
    detect_anomalies,
    gather_report_data,
    delta_from_previous,
)

# ── Exercise 2, 4, 5: Dashboard rendering ────────────────────────────────────
from utils.dashboard import (
    render_session_sidebar,
    render_log_table,
    render_ab_comparison,
    render_monitoring_dashboard,
    render_production_report,
)

__all__ = [
    # logging_utils
    "LLMLogEntry",
    "logged_llm_call",
    "logged_chain_invoke",
    "load_logs",
    "append_log",
    "estimate_tokens",
    "calculate_cost",
    # alerts
    "check_latency_alert",
    "check_cost_alert",
    "check_error_rate_alert",
    "check_token_alert",
    "check_input_length",
    "run_all_post_call_checks",
    "load_alert_log",
    "LATENCY_THRESHOLD_S",
    "COST_THRESHOLD_USD",
    "ERROR_RATE_THRESHOLD",
    "INPUT_LENGTH_THRESHOLD",
    "TOKEN_THRESHOLD",
    # prompt_testing
    "get_prompt_version",
    "get_prompt_suffix",
    "compare_prompt_versions",
    "PROMPT_VERSION_A_SUFFIX",
    "PROMPT_VERSION_B_SUFFIX",
    # metrics
    "compute_session_stats",
    "compute_daily_stats",
    "compute_hourly_traffic",
    "compute_latency_histogram",
    "detect_anomalies",
    "gather_report_data",
    "delta_from_previous",
    # dashboard
    "render_session_sidebar",
    "render_log_table",
    "render_ab_comparison",
    "render_monitoring_dashboard",
    "render_production_report",
]
